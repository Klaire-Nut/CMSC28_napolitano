//Written by: Klaire Napolitano 1-BSCS
#include <iostream>
using namespace std;

// Variable Declaraction 
int x, y, z, largest, smallest, difference;

//This function displays/prints the program description
void programDescription() {
    cout << "\n=====================================================================================================" << endl;
    cout << "This program finds the highest and lowest number among three numbers, and calculates their difference" << endl;
    cout << "Programmer Name: Klaire S. Napolitano " << endl;
    cout << "Date: 04/27/24 " << endl;
    cout << "Subject Number: CMSC 28" << endl;
    cout << "=====================================================================================================" << endl;

}
// This function gets the value of the 3 integers
void userInput(int &x, int &y, int &z){
    cout << "\nInput your 3 integers: \n" << endl;
    cin >> x >> y >> z;
}

// This function finds the largest value among the 3 user-input variables
void findLargest(int x, int y, int z){
    largest = x;
    if ( y > x)
        largest = y;
    if ( z > y)
        largest = z;
}

// This function finds the smallest value among the 3 user-input variables
void findSmallest(int x, int y, int z){
    smallest = x;
    if (y < x)
        smallest = y;
    if (z < y)
        smallest = z;
}
//This function display the highest value, lowest value, and difference of the 3 user-input variables
int displayData(int x, int y, int z, int largest, int smallest, int difference){
    cout << "=====================================================================================================" << endl;
    cout << "\n The user-input integers: " << x << ", " << y << ", "<< z << endl;
    cout << "\n The Highest value integer: " << largest << endl;
    cout << "\n The Lowest value integer: " << smallest << endl;
    cout << "\n The difference of the highest and lowest value: " << difference << endl;
}

//This is the main function where the functions are called to
int main() {

    programDescription();//calls programDescription function
    userInput(x, y, z); //calls userInput function

    findLargest(x, y, z); //calls findLargest function
    findSmallest(x, y, z); //calls findSmallest function
    difference = largest - smallest; //gets the difference of the largest and smallest value integer

    displayData(x, y, z, largest, smallest, difference); //calls displayData function

    return 0;

}