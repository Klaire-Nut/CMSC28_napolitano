//Written by: Klaire S. Napolitano
#include <iostream>
#include <algorithm> // Added for reverse function

using namespace std;

// Variable Declaration 
int decimal;

//This function displays/prints the program description
void programDescription() {
    cout << "\n=====================================================================================================" << endl;
    cout << "This program converts a decimal number to its binary equivalent." << endl;
    cout << "Programmer Name: Klaire S. Napolitano " << endl;
    cout << "Date: 04/27/24 " << endl;
    cout << "Subject Number: CMSC 28" << endl;
    cout << "=====================================================================================================" << endl;

}

// Function to convert decimal to binary
void decimalToBinary(int n) {
    if (n == 0) {
        cout << 0;
        return;
    }

    int binary[32]; // Assuming 32-bit integer
    int i = 0;

    // Convert decimal to binary
    while (n > 0) {
        binary[i] = n % 2;
        n /= 2;
        i++;
    }

    // Displaying the binary equivalent
    for (int j = i - 1; j >= 0; j--) {
        cout << binary[j];
    }
}

int main() {

    programDescription();//Calling Function to display program Description 

    // Input from the user
    cout << "Enter a decimal number: ";
    cin >> decimal;

    // Convert decimal to binary and display
    cout << "Binary equivalent: ";
    decimalToBinary(decimal);
    cout << endl;

    return 0;
}
