#ifndef STUDENT_H
#define STUDENT_H

#include "Person.h"

class Student : public Person {
private:
    std::string studentNum;

public:
    std::string course;
    std::string department;
    std::string college;

    // Setters with validation for Student-specific attributes
    void setStudentNum(const std::string &num) {
        if (num.empty()) {
            throw std::invalid_argument("Student number cannot be empty.");
        }
        studentNum = num;
    }

    void setCourse(const std::string &crs) {
        if (crs.empty()) {
            throw std::invalid_argument("Course cannot be empty.");
        }
        course = crs;
    }

    void setDepartment(const std::string &dept) {
        if (dept.empty()) {
            throw std::invalid_argument("Department cannot be empty.");
        }
        department = dept;
    }

    void setCollege(const std::string &coll) {
        if (coll.empty()) {
            throw std::invalid_argument("College cannot be empty.");
        }
        college = coll;
    }

    // Getters for Student-specific attributes
    std::string getStudentNum() const { return studentNum; }
    std::string getCourse() const { return course; }
    std::string getDepartment() const { return department; }
    std::string getCollege() const { return college; }

    // Function to input and validate student number
    void inputStudentNum() {
        std::string input;
        while (true) {
            std::cout << "Enter Student Number: ";
            std::cin >> input;
            try {
                setStudentNum(input);
                break;
            } catch (const std::invalid_argument &e) {
                std::cerr << "Error: " << e.what() << "\nPlease try again.\n";
            }
        }
    }

    // Function to input and validate course
    void inputCourse() {
        std::string input;
        while (true) {
            std::cout << "Enter Course: ";
            std::cin.ignore();
            std::getline(std::cin, input);
            try {
                setCourse(input);
                break;
            } catch (const std::invalid_argument &e) {
                std::cerr << "Error: " << e.what() << "\nPlease try again.\n";
            }
        }
    }

    // Function to input and validate department
    void inputDepartment() {
        std::string input;
        while (true) {
            std::cout << "Enter Department: ";
            std::cin.ignore();
            std::getline(std::cin, input);
            try {
                setDepartment(input);
                break;
            } catch (const std::invalid_argument &e) {
                std::cerr << "Error: " << e.what() << "\nPlease try again.\n";
            }
        }
    }

    // Function to input and validate college
    void inputCollege() {
        std::string input;
        while (true) {
            std::cout << "Enter College: ";
            std::getline(std::cin, input);
            try {
                setCollege(input);
                break;
            } catch (const std::invalid_argument &e) {
                std::cerr << "Error: " << e.what() << "\nPlease try again.\n";
            }
        }
    }
};

#endif 
