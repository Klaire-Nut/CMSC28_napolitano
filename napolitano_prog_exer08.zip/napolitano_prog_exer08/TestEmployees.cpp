#include <iostream>
#include "Employees.h"

int main() {
    try {
        Employees employee;

        employee.inputFirstName();
        employee.inputLastName();
        employee.inputGender();
        employee.inputEmailAdd();
        employee.inputCpNumber();
        employee.inputEmpNum();
        employee.inputPosition();
        employee.inputOffice();
        employee.inputSalary();

        std::cout << "\n\n=================================================================\n";
        std::cout << "| This program will demonstrate employee information management. |\n";
        std::cout << "=================================================================\n";
        std::cout << "| Programmed by: Klaire Napolitano       1-BSCS        05/30/24  |\n";
        std::cout << "-----------------------------------------------------------------\n";
        std::cout << "Employee First Name: " << employee.getFirstName() << "\n";
        std::cout << "Employee Last Name: " << employee.getLastName() << "\n";
        std::cout << "Employee Gender: " << employee.getGender() << "\n";
        std::cout << "Employee Email: " << employee.emailAdd << "\n";
        std::cout << "Employee Contact Number: " << employee.cpNumber << "\n";
        std::cout << "Employee Number: " << employee.getEmpNum() << "\n";
        std::cout << "Position: " << employee.getPosition() << "\n";
        std::cout << "Office/Unit: " << employee.getOffice() << "\n";
        std::cout << "Salary: $" << employee.getSalary() << "\n\n";

        std::cout << "==============================================================================================\n";
        std::cout << "Sample Output: Hello, " << employee.getFirstName() << " " << employee.getLastName() << "! \n";
        std::cout << "You are employed as a " << employee.getPosition() << " in the " << employee.getOffice() << ". \n";
        std::cout << "Your Employee number is " << employee.getEmpNum() << " and your salary is $" << employee.getSalary() << ".\n";
        std::cout << "==============================================================================================\n";
    } catch (const std::invalid_argument &e) {
        std::cerr << "Error: " << e.what() << "\n";
    }

    return 0;
}
