#include <iostream>
#include "Student.h"

int main() {
    try {
        Student student;

        student.inputFirstName();
        student.inputLastName();
        student.inputGender();
        student.inputEmailAdd();
        student.inputCpNumber();
        student.inputStudentNum();
        student.inputCourse();
        student.inputDepartment();
        student.inputCollege();

        std::cout << "=================================================================\n";
        std::cout << "| This program will demonstrate student information management. |\n";
        std::cout << "=================================================================\n";
        std::cout << "| Programmed by: Klaire Napolitano       1-BSCS        05/30/24  |\n";
        std::cout << "-----------------------------------------------------------------\n";
        std::cout << "Student First Name: " << student.getFirstName() << "\n";
        std::cout << "Student Last Name: " << student.getLastName() << "\n";
        std::cout << "Student Gender: " << student.getGender() << "\n";
        std::cout << "Student Email: " << student.emailAdd << "\n";
        std::cout << "Student Contact Number: " << student.cpNumber << "\n";
        std::cout << "Student Number: " << student.getStudentNum() << "\n";
        std::cout << "Course: " << student.getCourse() << "\n";
        std::cout << "Department: " << student.getDepartment() << "\n";
        std::cout << "College: " << student.getCollege() << "\n\n";

        std::cout << "==============================================================================================\n";
        std::cout << "Sample Output: Hi, " << student.getFirstName() << " " << student.getLastName() << "! Welcome to UP Mindanao and congratulations! \n";
        std::cout << "We are pleased to inform you that you are admitted in the " << student.getCourse() << " program under the \n";
        std::cout << student.getDepartment() << ", College of " << student.getCollege() << ". \nYour Student number is " << student.getStudentNum() << ".\n";
        std::cout << "==============================================================================================\n";
    } catch (const std::invalid_argument &e) {
        std::cerr << "Error: " << e.what() << "\n";
    }

    return 0;
}
