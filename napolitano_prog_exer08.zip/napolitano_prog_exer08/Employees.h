#ifndef EMPLOYEES_H
#define EMPLOYEES_H

#include "Person.h"
#include <limits> // For numeric limits

class Employees : public Person {
private:
    std::string empNum;

public:
    std::string position;
    std::string office;
    double salary;

    // Setters with validation for Employees-specific attributes
    void setEmpNum(const std::string &num) {
        if (num.empty()) {
            throw std::invalid_argument("Employee number cannot be empty.");
        }
        empNum = num;
    }

    void setPosition(const std::string &pos) {
        if (pos.empty()) {
            throw std::invalid_argument("Position cannot be empty.");
        }
        position = pos;
    }

    void setOffice(const std::string &off) {
        if (off.empty()) {
            throw std::invalid_argument("Office/Unit cannot be empty.");
        }
        office = off;
    }

    void setSalary(double sal) {
        if (sal <= 0) {
            throw std::invalid_argument("Salary must be greater than zero.");
        }
        salary = sal;
    }

    // Getters for Employees-specific attributes
    std::string getEmpNum() const { return empNum; }
    std::string getPosition() const { return position; }
    std::string getOffice() const { return office; }
    double getSalary() const { return salary; }

    // Function to input and validate employee number
    void inputEmpNum() {
        std::string input;
        while (true) {
            std::cout << "Enter Employee Number: ";
            std::cin >> input;
            try {
                setEmpNum(input);
                break;
            } catch (const std::invalid_argument &e) {
                std::cerr << "Error: " << e.what() << "\nPlease try again.\n";
            }
        }
    }

    // Function to input and validate position
    void inputPosition() {
        std::string input;
        while (true) {
            std::cout << "Enter Position: ";
            std::cin.ignore();
            std::getline(std::cin, input);
            try {
                setPosition(input);
                break;
            } catch (const std::invalid_argument &e) {
                std::cerr << "Error: " << e.what() << "\nPlease try again.\n";
            }
        }
    }

    // Function to input and validate office
    void inputOffice() {
        std::string input;
        while (true) {
            std::cout << "Enter Office/Unit: ";
            std::cin.ignore();
            std::getline(std::cin, input);
            try {
                setOffice(input);
                break;
            } catch (const std::invalid_argument &e) {
                std::cerr << "Error: " << e.what() << "\nPlease try again.\n";
            }
        }
    }

    // Function to input and validate salary
    void inputSalary() {
        double input;
        while (true) {
            std::cout << "Enter Salary: ";
            std::cin >> input;
            if (std::cin.fail()) { // Check if input is a valid number
                std::cin.clear(); // Clear the error flag
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Ignore invalid input
                std::cerr << "Error: Invalid input. Please enter a numeric value.\n";
                continue;
            }
            try {
                setSalary(input);
                break;
            } catch (const std::invalid_argument &e) {
                std::cerr << "Error: " << e.what() << "\nPlease try again.\n";
            }
        }
    }
};

#endif 
