#ifndef PERSON_H
#define PERSON_H

#include <string>
#include <stdexcept>
#include <iostream>

class Person {
private:
    std::string fname;
    std::string lname;
    std::string gender;

    // Helper function to check if a string contains only alphabetic characters
    bool isAlpha(const std::string &str) const {
        for (char c : str) {
            if (!isalpha(c)) {
                return false;
            }
        }
        return true;
    }

public:
    std::string emailAdd;
    std::string cpNumber;

    // Function to set first name with validation
    void setFirstName(const std::string &firstName) {
        if (firstName.empty() || !isAlpha(firstName)) {
            throw std::invalid_argument("First name must contain only alphabetic characters and cannot be empty.");
        }
        fname = firstName;
    }

    // Function to set last name with validation
    void setLastName(const std::string &lastName) {
        if (lastName.empty() || !isAlpha(lastName)) {
            throw std::invalid_argument("Last name must contain only alphabetic characters and cannot be empty.");
        }
        lname = lastName;
    }

    // Function to set gender with validation
    void setGender(const std::string &gen) {
        if (gen != "M" && gen != "F") {
            throw std::invalid_argument("Gender must be 'M' for male or 'F' for female.");
        }
        gender = gen;
    }

    // Getters for the attributes
    std::string getFirstName() const { return fname; }
    std::string getLastName() const { return lname; }
    std::string getGender() const { return gender; }

    // Function to input and validate first name
    void inputFirstName() {
        std::string input;
        while (true) {
            std::cout << "Enter First Name: ";
            std::cin >> input;
            try {
                setFirstName(input);
                break;
            } catch (const std::invalid_argument &e) {
                std::cerr << "Error: " << e.what() << "\nPlease try again.\n";
            }
        }
    }

    // Function to input and validate last name
    void inputLastName() {
        std::string input;
        while (true) {
            std::cout << "Enter Last Name: ";
            std::cin >> input;
            try {
                setLastName(input);
                break;
            } catch (const std::invalid_argument &e) {
                std::cerr << "Error: " << e.what() << "\nPlease try again.\n";
            }
        }
    }

    // Function to input and validate gender
    void inputGender() {
        std::string input;
        while (true) {
            std::cout << "Enter Gender (M/F): ";
            std::cin >> input;
            try {
                setGender(input);
                break;
            } catch (const std::invalid_argument &e) {
                std::cerr << "Error: " << e.what() << "\nPlease try again.\n";
            }
        }
    }

    // Function to set email address with validation
    void setEmailAdd(const std::string &email) {
        if (email.empty()) {
            throw std::invalid_argument("Email address cannot be empty.");
        }
        emailAdd = email;
    }

    // Function to set contact number with validation
    void setCpNumber(const std::string &cpNum) {
        if (cpNum.empty()) {
            throw std::invalid_argument("Contact number cannot be empty.");
        }
        cpNumber = cpNum;
    }

    // Function to input and validate email address
    void inputEmailAdd() {
        std::string input;
        while (true) {
            std::cout << "Enter Email Address: ";
            std::cin >> input;
            try {
                setEmailAdd(input);
                break;
            } catch (const std::invalid_argument &e) {
                std::cerr << "Error: " << e.what() << "\nPlease try again.\n";
            }
        }
    }

    // Function to input and validate contact number
    void inputCpNumber() {
        std::string input;
        while (true) {
            std::cout << "Enter Contact Number: ";
            std::cin >> input;
            try {
                setCpNumber(input);
                break;
            } catch (const std::invalid_argument &e) {
                std::cerr << "Error: " << e.what() << "\nPlease try again.\n";
            }
        }
    }
};

#endif 