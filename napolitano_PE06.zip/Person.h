#ifndef PERSON_H
#define PERSON_H

#include <string>
#include <stdexcept>

class Person {
private:
    std::string fname;
    std::string lname;
    std::string gender;

    bool isAlpha(const std::string &str) const {
        for (char c : str) {
            if (!isalpha(c)) {
                return false;
            }
        }
        return true;
    }

public:
    void setFirstName(const std::string &firstName) {
        if (firstName.empty() || !isAlpha(firstName)) {
            throw std::invalid_argument("First name must contain only alphabetic characters and cannot be empty.");
        }
        fname = firstName;
    }

    void setLastName(const std::string &lastName) {
        if (lastName.empty() || !isAlpha(lastName)) {
            throw std::invalid_argument("Last name must contain only alphabetic characters and cannot be empty.");
        }
        lname = lastName;
    }

    void setGender(const std::string &gen) {
        if (gen != "M" && gen != "F") {
            throw std::invalid_argument("Gender must be 'M' for male or 'F' for female.");
        }
        gender = gen;
    }

    std::string getFirstName() const {
        return fname;
    }

    std::string getLastName() const {
        return lname;
    }

    std::string getGender() const {
        return gender;
    }
};

#endif // PERSON_H
