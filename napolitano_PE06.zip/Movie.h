#ifndef MOVIE_H
#define MOVIE_H

#include <string>
#include <vector>
#include "Person.h" // Forward declaration

class Movie {
private:
    std::string title;
    std::string synopsis;
    std::string mpaaRating;
    std::string genre;
    std::vector<Person> directors;
    std::vector<Person> actors;

public:
    // Function prototypes
    void setTitle(const std::string &movieTitle);
    void setSynopsis(const std::string &movieSynopsis);
    void setMpaaRating(const std::string &rating);
    void setGenre(const std::string &movieGenre);
    void addDirector(const Person &movieDirector);
    void addActor(const Person &actor);
    std::string getTitle() const;
    std::string getSynopsis() const;
    std::string getMpaaRating() const;
    std::string getGenre() const;
    std::vector<Person> getDirectors() const;
    std::vector<Person> getActors() const;
};

// Function definitions
void Movie::setTitle(const std::string &movieTitle) {
    if (movieTitle.empty()) {
        throw std::invalid_argument("Movie title cannot be empty.");
    }
    title = movieTitle;
}

void Movie::setSynopsis(const std::string &movieSynopsis) {
    if (movieSynopsis.empty()) {
        throw std::invalid_argument("Movie synopsis cannot be empty.");
    }
    synopsis = movieSynopsis;
}

void Movie::setMpaaRating(const std::string &rating) {
    if (rating != "G" && rating != "PG" && rating != "PG-13" && rating != "R" && rating != "X") {
        throw std::invalid_argument("Invalid MPAA rating. Valid ratings are 'G', 'PG', 'PG-13', 'R', and 'X'.");
    }
    mpaaRating = rating;
}

void Movie::setGenre(const std::string &movieGenre) {
    if (movieGenre.empty()) {
        throw std::invalid_argument("Movie genre cannot be empty.");
    }
    genre = movieGenre;
}

void Movie::addDirector(const Person &movieDirector) {
    directors.push_back(movieDirector);
}

void Movie::addActor(const Person &actor) {
    actors.push_back(actor);
}

std::string Movie::getTitle() const {
    return title;
}

std::string Movie::getSynopsis() const {
    return synopsis;
}

std::string Movie::getMpaaRating() const {
    return mpaaRating;
}

std::string Movie::getGenre() const {
    return genre;
}

std::vector<Person> Movie::getDirectors() const {
    return directors;
}

std::vector<Person> Movie::getActors() const {
    return actors;
}

#endif // MOVIE_H
