//Written by: Klaire Napolitano 1-BSCS
// 05/18/24

#include <iostream>
#include <string>
#include <vector>
#include "Movie.h"
#include "Person.h"

using namespace std;

int main() {
    char continueInput;

    do {
        Movie movie;
        Person person;

        cout << "=================================================================================================================\n";
        cout << "\nThis program prompts the user to input movie details, stores this information in the respective class instances\n";
        cout << "and then displays the entered details.\n";
        cout << "Programmed by: Klaire S. Napolitano  1-BSCS \n\n";
        cout << "=================================================================================================================\n";
        
        // Prompt user to enter movie details
        cout << "Enter Movie Title: ";
        string input;
        getline(cin, input);
        movie.setTitle(input);

        cout << "Enter Synopsis: ";
        getline(cin, input);
        movie.setSynopsis(input);

        cout << "What is its MPAA Rating: ";
        getline(cin, input);
        movie.setMpaaRating(input);

        cout << "What is the Genre: ";
        getline(cin, input);
        movie.setGenre(input);

        // Prompt user to enter directors
        int numDirectors;
        cout << "How many directors? ";
        cin >> numDirectors;
        cin.ignore(); // Clear the input buffer

        for (int i = 0; i < numDirectors; ++i) {
            cout << "Enter details for director " << i + 1 << " (first name, last name, gender): ";
            string fname, lname, gender;
            cin >> fname >> lname >> gender;
            cin.ignore(); // Clear the input buffer
            Person director;
            director.setFirstName(fname);
            director.setLastName(lname);
            director.setGender(gender);
            movie.addDirector(director);
        }

        // Prompt user to enter actors
        int numActors;
        cout << "How many actors? ";
        cin >> numActors;
        cin.ignore(); // Clear the input buffer

        for (int i = 0; i < numActors; ++i) {
            cout << "Enter details for actor " << i + 1 << " (first name, last name, gender): ";
            string fname, lname, gender;
            cin >> fname >> lname >> gender;
            cin.ignore(); // Clear the input buffer
            Person actor;
            actor.setFirstName(fname);
            actor.setLastName(lname);
            actor.setGender(gender);
            movie.addActor(actor);
        }

        // Display the movie details
        cout << "-------------------------------------------------------------\n";
        cout << "                    MOVIE DETAILS                          \n";
        cout << "-------------------------------------------------------------\n";
        cout << "Movie Title    : " << movie.getTitle() << "\n";
        cout << "Synopsis       : " << movie.getSynopsis() << "\n";
        cout << "MPAA Rating    : " << movie.getMpaaRating() << "\n";
        cout << "Genre          : " << movie.getGenre() << "\n\n";

        // Display directors
        vector<Person> directors = movie.getDirectors();
        cout << "Directors:\n";
        for (size_t i = 0; i < directors.size(); ++i) {
            cout << "   " << directors[i].getFirstName() << " " << directors[i].getLastName() << " (" << directors[i].getGender() << ")\n";
        }

        // Display actors
        vector<Person> actors = movie.getActors();
        cout << "\nActors:\n";
        for (size_t i = 0; i < actors.size(); ++i) {
            cout << "   " << actors[i].getFirstName() << " " << actors[i].getLastName() << " (" << actors[i].getGender() << ")\n";
        }

        cout << "-------------------------------------------------------------\n";

        // Prompt user to continue or not
        cout << "Do you want to input another movie? (Y/N): ";
        cin >> continueInput;
        cin.ignore(); // Clear the input buffer
        cout << "\n";

    } while (continueInput == 'Y' || continueInput == 'y');

    return 0;
}

