//Written by: Klaire Npaolitano     1-BSCS      05/11/24

#include <string>
using namespace std;

class Book {
private:
    string Title; // Attribute for storing the title of the book
    string Author; // Attribute for storing the author of the book
    string ISBN; // Attribute for storing the ISBN of the book
    string Publisher; // Attribute for storing the publisher of the book

public:
    Book(string title, string author, string isbn); // Constructor declaration
    string getTitle(); // Getter method declaration for the title
    string getAuthor(); // Getter method declaration for the author
    string getISBN(); // Getter method declaration for the ISBN
    string getPublisher(); // Getter method declaration for the publisher
    void setTitle(string bktitle); // Setter method declaration for the title
    void setAuthor(string bkauthor); // Setter method declaration for the author
    void setISBN(string bkisbn); // Setter method declaration for the ISBN
    void setPublisher(string bkpublisher); // Setter method declaration for the publisher
};

// Constructor definition
Book::Book(string title, string author, string isbn) {
    Title = title; // Assigning value to the Title attribute
    Author = author; // Assigning value to the Author attribute
    ISBN = isbn; // Assigning value to the ISBN attribute
}
// Getter method definitions
string Book::getTitle() {
    return Title; // Returning the value of the Title attribute
}
string Book::getAuthor() {
    return Author; // Returning the value of the Author attribute
}
string Book::getISBN() {
    return ISBN; // Returning the value of the ISBN attribute
}
string Book::getPublisher() {
    return Publisher; // Returning the value of the Publisher attribute
}
// Setter method definitions
void Book::setTitle(string bktitle) {
    Title = bktitle; // Setting the value of the Title attribute
}
void Book::setAuthor(string bkauthor) {
    Author = bkauthor; // Setting the value of the Author attribute
}
void Book::setISBN(string bkisbn) {
    ISBN = bkisbn; // Setting the value of the ISBN attribute
}
void Book::setPublisher(string bkpublisher) {
    Publisher = bkpublisher; // Setting the value of the Publisher attribute
}
