//Written by: Klaire Npaolitano     1-BSCS      05/11/24

#include <iostream>
#include "Book.h" // Including the header file for the Book class
using namespace std;

int main() {
    // Creating a Book object
    Book myBook("A Calamity of Souls", "Baldacci, David", "9781538765029");

    // Testing methods
    cout << "Title: " << myBook.getTitle() << endl; // Printing the title of the book
    cout << "Author: " << myBook.getAuthor() << endl; // Printing the author of the book
    cout << "ISBN: " << myBook.getISBN() << endl; // Printing the ISBN of the book

    // Testing setters
    myBook.setTitle("To Kill a Mockingbird"); // Setting a new title for the book
    myBook.setAuthor("Harper Lee"); // Setting a new author for the book
    myBook.setISBN("9780061120084"); // Setting a new ISBN for the book
    myBook.setPublisher("HarperCollins"); // Setting a publisher for the book

    cout << "\nUpdated Book Details:\n";
    cout << "Title: " << myBook.getTitle() << endl; // Printing the updated title of the book
    cout << "Author: " << myBook.getAuthor() << endl; // Printing the updated author of the book
    cout << "ISBN: " << myBook.getISBN() << endl; // Printing the updated ISBN of the book
    cout << "Publisher: " << myBook.getPublisher() << endl; // Printing the publisher of the book

    return 0;
}
