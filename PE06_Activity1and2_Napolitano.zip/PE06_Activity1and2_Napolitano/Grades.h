#include <iostream>
#include <string>
using namespace std;

class Grades{
    private:
    string subject;
    float grade;
    
    public:
        Grades(){}

    Grades(float yourGrade){
        subject = "Mathematics";
        grade = yourGrade;
}

    void setsubject(string SUBJECT){
        if(!SUBJECT.empty()){
            subject = SUBJECT;
        } else {
            cout << "invalid subject input!!!" << endl;
            }
        }
    string getsubject(){
        return subject;
    }
Grades (string SUBJECT, float GRADE){
    grade = GRADE;
    subject = SUBJECT;
}

void setgrade(float GRADE){
        if(GRADE >= 0 && GRADE <= 100){
            grade = GRADE;
            if(GRADE >= 60){
                cout << "You passed this subject!!!" << endl;
            } else {
                cout << "You have failed this subject!!!" << endl;
                }
            } else {
                cout << "invalid grade!!!" << endl;
            }
        }

        float getgrade(){
            return grade;
        }

// Method view is an overloaded method. This means that we have the same method
// name but with different signature: (), (int age) and (int age, char gender)
void view(){
cout << "\nThis person is taking this subject " << getsubject() << endl;
cout << "\nThis person's grade is = " << getgrade() << endl;
}

};
