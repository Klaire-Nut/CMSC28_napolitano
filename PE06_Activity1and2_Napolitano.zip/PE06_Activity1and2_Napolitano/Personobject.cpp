#include <iostream>
#include <string>
#include "Person.h" // add Person.h as a library to this program
#include "Grades.h"
using namespace std;

int main(){
    int a;
    char g;
    string subject;
    float grade;

    cout << "Activity 2" << endl;

    Person p;
    cout << "\nInput age: ";
    cin >> a;
    p.setage(a);
    cout << "Input gender: ";
    cin >> g;
    p.setgender(g);
    cout << "Age = " << p.getage() << endl;
    cout << "Gender = " << p.getgender() << endl;

    Grades d;
    cout << "\nInput subject: ";
    cin >> subject;
    d.setsubject(subject);
    cout << "Input grade: ";
    cin >> grade;
    d.setgrade(grade);
    cout << "Subject = " << d.getsubject() << endl;
    cout << "Grade = " << d.getgrade() << endl;

}
