#include <iostream>
#include <string>
using namespace std;

class iceCream{
    private:
    float price;
    string flavor;
    int expiryYear ;

public:

    iceCream (float PRICE, string FLAVOR, int EXPIRYYEAR){
        price = PRICE;
        flavor = FLAVOR;
        expiryYear = EXPIRYYEAR;
    }
    

void view(){
    cout << "---------------------------ICECREAM----------------------------------\n" << endl;
    cout << "The price of the Icecream of your choice is  = " << price << endl;
    cout << "\nYour selected flavor is " << flavor << endl;
    cout << "\nThis Icecream will expire in year " << expiryYear << endl;
}
};