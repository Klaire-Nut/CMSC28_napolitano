//Written by: Klaire Napolitano

#include <iostream>
#include <string>
#include "icecream.h"
using namespace std;


int main(){
    float PRICE;
    string FLAVOR;
    int EXPIRYYEAR;

    iceCream a( 112.36, "Banana", 2038 );
    
    a.view();
}