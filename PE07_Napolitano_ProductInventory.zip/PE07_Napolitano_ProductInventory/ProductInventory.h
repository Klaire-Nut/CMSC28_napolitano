// ProductInventory.h

#ifndef PRODUCTINVENTORY_H
#define PRODUCTINVENTORY_H

#include <string>

// Base class Product
class Product {
private:
    std::string name;
    std::string brand;
    double price;
    int quantity;
    std::string description;
    std::string category;

public:
    // Constructor
    Product(const std::string& name, const std::string& brand, double price, int quantity, const std::string& description, const std::string& category);

    // Getters
    std::string getName() const;
    std::string getBrand() const;
    double getPrice() const;
    int getQuantity() const;
    std::string getDescription() const;
    std::string getCategory() const;

    // Setters
    void setName(const std::string& name);
    void setBrand(const std::string& brand);
    void setPrice(double price);
    void setQuantity(int quantity);
    void setDescription(const std::string& description);
    void setCategory(const std::string& category);

    // Virtual method to print details
    virtual void printDetails() const;
};

// Derived class Clothing
class Clothing : public Product {
private:
    std::string size;
    std::string color;
    std::string material;

public:
    // Constructor
    Clothing(const std::string& name, const std::string& brand, double price, int quantity, const std::string& description, const std::string& category,
             const std::string& size, const std::string& color, const std::string& material);

    // Getters
    std::string getSize() const;
    std::string getColor() const;
    std::string getMaterial() const;

    // Setters
    void setSize(const std::string& size);
    void setColor(const std::string& color);
    void setMaterial(const std::string& material);

    // Override printDetails method
    void printDetails() const override;
};

// Derived class Electronics
class Electronics : public Product {
private:
    std::string model;
    int warranty; // warranty period in months
    std::string technicalSpecifications;

public:
    // Constructor
    Electronics(const std::string& name, const std::string& brand, double price, int quantity, const std::string& description, const std::string& category,
                const std::string& model, int warranty, const std::string& technicalSpecifications);

    // Getters
    std::string getModel() const;
    int getWarranty() const;
    std::string getTechnicalSpecifications() const;

    // Setters
    void setModel(const std::string& model);
    void setWarranty(int warranty);
    void setTechnicalSpecifications(const std::string& technicalSpecifications);

    // Override printDetails method
    void printDetails() const override;
};

#endif // PRODUCTINVENTORY_H
