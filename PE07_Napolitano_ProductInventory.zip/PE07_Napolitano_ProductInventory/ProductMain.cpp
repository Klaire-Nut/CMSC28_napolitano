// ProductMain.cpp

#include "ProductInventory.h"
#include <iostream>
#include <limits>

// Implementations of Product methods
Product::Product(const std::string& name, const std::string& brand, double price, int quantity, const std::string& description, const std::string& category)
    : name(name), brand(brand), price(price), quantity(quantity), description(description), category(category) {}

std::string Product::getName() const { return name; }
std::string Product::getBrand() const { return brand; }
double Product::getPrice() const { return price; }
int Product::getQuantity() const { return quantity; }
std::string Product::getDescription() const { return description; }
std::string Product::getCategory() const { return category; }

void Product::setName(const std::string& name) { this->name = name; }
void Product::setBrand(const std::string& brand) { this->brand = brand; }
void Product::setPrice(double price) { this->price = price; }
void Product::setQuantity(int quantity) { this->quantity = quantity; }
void Product::setDescription(const std::string& description) { this->description = description; }
void Product::setCategory(const std::string& category) { this->category = category; }

void Product::printDetails() const {
    std::cout << "Product Name: " << name << "\nBrand: " << brand << "\nPrice: $" << price 
              << "\nQuantity: " << quantity << "\nDescription: " << description 
              << "\nCategory: " << category << std::endl;
}

// Implementations of Clothing methods
Clothing::Clothing(const std::string& name, const std::string& brand, double price, int quantity, const std::string& description, const std::string& category,
                   const std::string& size, const std::string& color, const std::string& material)
    : Product(name, brand, price, quantity, description, category), size(size), color(color), material(material) {}

std::string Clothing::getSize() const { return size; }
std::string Clothing::getColor() const { return color; }
std::string Clothing::getMaterial() const { return material; }

void Clothing::setSize(const std::string& size) { this->size = size; }
void Clothing::setColor(const std::string& color) { this->color = color; }
void Clothing::setMaterial(const std::string& material) { this->material = material; }

void Clothing::printDetails() const {
    Product::printDetails();
    std::cout << "Size: " << size << "\nColor: " << color << "\nMaterial: " << material << std::endl;
}

// Implementations of Electronics methods
Electronics::Electronics(const std::string& name, const std::string& brand, double price, int quantity, const std::string& description, const std::string& category,
                         const std::string& model, int warranty, const std::string& technicalSpecifications)
    : Product(name, brand, price, quantity, description, category), model(model), warranty(warranty), technicalSpecifications(technicalSpecifications) {}

std::string Electronics::getModel() const { return model; }
int Electronics::getWarranty() const { return warranty; }
std::string Electronics::getTechnicalSpecifications() const { return technicalSpecifications; }

void Electronics::setModel(const std::string& model) { this->model = model; }
void Electronics::setWarranty(int warranty) { this->warranty = warranty; }
void Electronics::setTechnicalSpecifications(const std::string& technicalSpecifications) { this->technicalSpecifications = technicalSpecifications; }

void Electronics::printDetails() const {
    Product::printDetails();
    std::cout << "Model: " << model << "\nWarranty: " << warranty << " months"
              << "\nTechnical Specifications: " << technicalSpecifications << std::endl;
}

// Utility function to clear the input stream
void clearInputStream() {
    std::cin.clear();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}

// Main function
int main() {
    std::string name, brand, description, category, size, color, material, model, technicalSpecifications;
    double price;
    int quantity, warranty;

    std::cout << "==========================================================================================================================\n" << std::endl;
    std::cout << "                                                Written by: Klaire Napolitano                                             \n" << std::endl;
    std::cout << "============This program prompts the user to input details for a clothing product and an electronics product==============\n" << std::endl;
    std::cout << "==========================================================================================================================\n" << std::endl;
    // User input for Clothing
    std::cout << "=======================================" << std::endl;
    std::cout << "Enter details for Clothing product:" << std::endl;
    std::cout << "=======================================" << std::endl;
    std::cout << "Name: ";
    std::getline(std::cin, name);
    std::cout << "\nBrand: ";
    std::getline(std::cin, brand);

    while (true) {
        std::cout << "\nPrice: ";
        std::cin >> price;
        if (std::cin.fail() || price < 0) {
            std::cout << "Invalid input. Please enter a positive number for the price." << std::endl;
            clearInputStream();
        } else {
            break;
        }
    }

    while (true) {
        std::cout << "\nQuantity: ";
        std::cin >> quantity;
        if (std::cin.fail() || quantity < 0) {
            std::cout << "Invalid input. Please enter a positive integer for the quantity." << std::endl;
            clearInputStream();
        } else {
            break;
        }
    }

    clearInputStream(); // Clear input buffer after reading numeric inputs

    std::cout << "\nDescription: ";
    std::getline(std::cin, description);
    std::cout << "\nCategory: ";
    std::getline(std::cin, category);
    std::cout << "\nSize: ";
    std::getline(std::cin, size);
    std::cout << "\nColor: ";
    std::getline(std::cin, color);
    std::cout << "\nMaterial: ";
    std::getline(std::cin, material);

    Clothing shirt(name, brand, price, quantity, description, category, size, color, material);

    // User input for Electronics
    std::cout << "=======================================" << std::endl;
    std::cout << "\nEnter details for Electronics product:" << std::endl;
    std::cout << "=======================================" << std::endl;
    std::cout << "Name: ";
    std::getline(std::cin, name);
    std::cout << "\nBrand: ";
    std::getline(std::cin, brand);

    while (true) {
        std::cout << "\nPrice: ";
        std::cin >> price;
        if (std::cin.fail() || price < 0) {
            std::cout << "Invalid input. Please enter a positive number for the price." << std::endl;
            clearInputStream();
        } else {
            break;
        }
    }

    while (true) {
        std::cout << "\nQuantity: ";
        std::cin >> quantity;
        if (std::cin.fail() || quantity < 0) {
            std::cout << "Invalid input. Please enter a positive integer for the quantity." << std::endl;
            clearInputStream();
        } else {
            break;
        }
    }

    clearInputStream(); // Clear input buffer after reading numeric inputs

    std::cout << "\nDescription: ";
    std::getline(std::cin, description);
    std::cout << "\nCategory: ";
    std::getline(std::cin, category);
    std::cout << "\nModel: ";
    std::getline(std::cin, model);

    while (true) {
        std::cout << "\nWarranty (in months): ";
        std::cin >> warranty;
        if (std::cin.fail() || warranty < 0) {
            std::cout << "Invalid input. Please enter a positive integer for the warranty." << std::endl;
            clearInputStream();
        } else {
            break;
        }
    }

    clearInputStream(); // Clear input buffer after reading numeric input

    std::cout << "\nTechnical Specifications: ";
    std::getline(std::cin, technicalSpecifications);

    Electronics laptop(name, brand, price, quantity, description, category, model, warranty, technicalSpecifications);

    std::cout << "\n========== Clothing Product ==========" << std::endl;
    shirt.printDetails();
    std::cout << "=======================================" << std::endl << std::endl;

    std::cout << "======== Electronics Product ==========" << std::endl;
    laptop.printDetails();
    std::cout << "=======================================" << std::endl;

    return 0;
}
